package grails.plugin.boselecta

import grails.converters.JSON
import grails.plugin.boselecta.interfaces.ClientSessions

import javax.websocket.Session

class BoSelectaTagLib implements ClientSessions {

	static namespace  =  "boselecta"

	def grailsApplication

	def clientListenerService
	def autoCompleteService
	
	
	
	def connect  =  { attrs ->
		def job = attrs.remove('job')?.toString()
		def actionMap = attrs.remove('actionMap')
		def jsonData = attrs.remove('jsonData')
		def receivers = attrs.remove('receivers')
		boolean strictMode = attrs.remove('strictMode')?.toBoolean() ?: false
		boolean autodisco = attrs.remove('autodisco')?.toBoolean() ?: false
		boolean masterNode = attrs.remove('masterNode')?.toBoolean() ?: false
		boolean frontenduser = attrs.remove('frontenduser')?.toBoolean() ?: false
		String hostname = attrs.remove('hostname')?.toString()
		String appName = attrs.remove('appName')?.toString()
		String user = attrs.remove('user')?.toString()
		String message = attrs.remove('message')?.toString()
		String divId = attrs.remove('divId')?.toString() ?: ''
		String sendType = attrs.remove('sendType')?.toString() ?: 'message'
		String event =  attrs.remove('event')?.toString()
		String context = attrs.remove('context')?.toString()
		String addAppName = config.add.appName ?: 'yes'
		if (receivers) {
			receivers = receivers as ArrayList
		}
		if (jsonData) {
			if(jsonData instanceof String) {
				jsonData =JSON.parse(jsonData)
			}
			jsonData = jsonData as JSON
		}

		String frontuser=''
		if (frontenduser) {
			frontuser=user+frontend
			if (receivers &&  (receivers instanceof ArrayList) ) {
			receivers.add(frontuser)
			}
		}

		if (actionMap) {
			actionMap = actionMap as Map
		}
		String dbSupport = config.dbsupport ?: 'yes'

		if (!appName) {
			appName = grailsApplication.metadata['app.name']
		}

		if (!hostname) {
			hostname = config.hostname ?: 'localhost:8080'
		}



		if (!message) {
			message = "testing"
		}

		String uri="ws://${hostname}/${appName}/${APP}/"
		if (addAppName=="no") {
			uri="ws://${hostname}/${APP}/"
		}
		

		Session oSession = clientListenerService.p_connect(uri, user, job)
		
		Map model = [  message : message, job: job, hostname: hostname, actionMap: actionMap,
			appName: appName, frontuser:frontuser,  user: user,  receivers: receivers, divId: divId,
			chatApp: APP, addAppName: addAppName ]
		
		if (frontenduser) {
			
			String userTemplate = attrs.socketProcessTemplate ?: config.socketProcessTemplate
			
			String defaultTemplate= "/${VIEW}/socketProcess"
			
			if (userTemplate) {
				out << g.render(template:userTemplate, model:model)
			}else{
				out << g.render(contextPath: pluginContextPath, template:"${defaultTemplate}", model: model)
			}
		}
		
		try{
			//closure(session)
			if (sendType == 'message') {
				if (receivers) {
					clientListenerService.sendArrayPM(oSession, job, message)
				}else{
					clientListenerService.sendMessage( oSession,  message)
				}
			//}else if (sendType == 'event') {
			//	clientListenerService.alertEvent(oSession, event, context, jsonData, job, masterNode, strictMode, autodisco, frontenduser)
			}

			if (autodisco) {
				clientListenerService.disconnect(oSession)
			}else{

			}
		}catch(e){
			//log.error e
		}

	}
	
	
	def selectPrimary = {attrs ->
		def clazz,name = ""
		def job = attrs.remove('job')?.toString()
		def user = attrs.remove('user')?.toString()
		if (!attrs.id) {
			throwTagError("Tag [selectPrimary] is missing required attribute [id]")
		}
		if (!attrs.domain) {
			throwTagError("Tag [selectPrimary] is missing required attribute [domain]")
		}
		if (!attrs.noSelection) {
			throwTagError("Tag [selectPrimary] is missing required attribute [noSelection]")
		}
		
		if ( (!attrs.controller) && (!attrs.action) ) {
			if (!attrs.domain2) {
				throwTagError("Tag [selectPrimary] is missing required attribute [domain2]")
			}
			if (!attrs.bindid) {
				throwTagError("Tag [selectPrimary] is missing required attribute [bindid]")
			}
			if (!attrs.searchField) {
				throwTagError("Tag [selectPrimary] is missing required attribute [searchField]")
			}
		}
		
		if (!attrs.controller) {
			attrs.controller= "autoComplete"
		}
		if (!attrs.action) {
			attrs.action= "ajaxSelectSecondary"
		}
		if (!attrs.setId) {
			attrs.setId = "selectPrimary"
		}
		if (!attrs.collectField) {
			attrs.collectField = attrs.searchField
		}
		if (attrs.class) {
			clazz = " class='${attrs.class}'"
		}
		if (attrs.name) {
			name = "${attrs.name}"
		} else {
			name = "${attrs.id}"
		}
		if (!attrs.collectField2) {
			attrs.collectField2=attrs.collectField
		}
		if (!attrs.searchField2) {
			attrs.searchField2=attrs.searchField
		}
		if ((attrs.appendValue)&&(!attrs.appendName)) {
			attrs.appendName='Values Updated'
		}
		Boolean requireField=true
		
		if (attrs.require) {
			requireField=attrs.remove('require')?.toBoolean()
		}
		
		
		List primarylist = autoCompleteService.returnPrimaryList(attrs.domain)
	
		
		String userTemplate = attrs.socketConnectTemplate ?: config.socketConnectTemplate
		String defaultTemplate = "/${VIEW}/socketConnect"
		
		if (userTemplate) {
			out << g.render(template:userTemplate, model: [attrs:attrs])
		}else{
			out << g.render(contextPath: pluginContextPath, template: defaultTemplate, model: [attrs:attrs])
		}
		
		
		def gsattrs=['optionKey' : "${attrs.collectField}" , 'optionValue': "${attrs.searchField}", 'id': "${attrs.id}", 
			'value': "${attrs.value}", 'name': "${name}"]
		gsattrs['from'] = primarylist
		if (requireField) {
			gsattrs['required'] = 'required'
		}

		
		gsattrs['noSelection'] =attrs.noSelection
		
		gsattrs['onchange'] = "javascript:actionThis(this.value, '${attrs.setId}', '${user}');"
		if (!attrs.secondaryValue) {
			attrs.secondaryValue=""
		}
		
		out << g.select(gsattrs)
		
		def message = [setId: "${attrs.setId}", secondary: "${attrs.domain2}", collectfield: "${attrs.collectField2}", 
			searchField:  "${attrs.searchField2}", bindId: attrs.bindid]
		def cc=message as JSON
		clientListenerService.sendJobMessage(job, cc as String)
		
		
	
		
		
		
	}
	
	/*
	// selectSecondary is used by both gsp calls to g:selectPrimary and g:selectSecondary
	def selectSecondary = {attrs ->
		def clazz,name = ""
		if (!attrs.id) {
			throwTagError("Tag [selectScondary] is missing required attribute [id]")
		}
		
		if ( (!attrs.controller) && (!attrs.action) ) {
			if (!attrs.searchField2) {
				throwTagError("Tag [selectScondary] is missing required attribute [searchField2]")
			}
			if (!attrs.domain2) {
				throwTagError("Tag [selectScondary] is missing required attribute [domain2]")
			}
			if (!attrs.bindid) {
				throwTagError("Tag [selectScondary] is missing required attribute [bindid]")
			}
		}
		
		if (!attrs.controller)  {
			attrs.controller= "autoComplete"
		}
		if (!attrs.action) {
			attrs.action= "ajaxSelectSecondary"
		}
		if (!attrs.noSelection) {
			throwTagError("Tag [selectScondary] is missing required attribute [noSelection]")
		}
		
		if (!attrs.setId) {
			attrs.setId = "selectSecondary"
		}
		
		if (!attrs.collectField2) {
			attrs.collectField2 = attrs.searchField2
		}
		if (!attrs.searchField) {
			attrs.searchField = attrs.searchField2
		}
		if (!attrs.collectField) {
			attrs.collectField = attrs.searchField2
		}
		if (attrs.class) {
			clazz = " class='${attrs.class}'"
		}
		if (attrs.name) {
			name = "${attrs.name}"
		} else {
			name = "${attrs.id}"
		}
		Boolean requireField=true
		if (attrs.require) {
			requireField=attrs.remove('require')?.toBoolean()
		}
		if ((attrs.appendValue)&&(!attrs.appendName)) {
			attrs.appendName='Values Updated'
		}

		
		List secondarylist=[]
		if (attrs.filter) {
			if (!attrs.filterController) {
				attrs.filterController=attrs.controller
			}
			if (!attrs.filteraction) {
				attrs.filteraction="loadFilterWord2"
			}
			if (!attrs.filteraction2) {
				attrs.filteraction2="secondarySearch"
			}
			if (!attrs.hidden) {
				attrs.hidden="hidden${attrs.id}"
			}
			if (!attrs.filterDisplay) {
				attrs.filterDisplay='all'
			}
			if (!attrs.filterbind) {
				throwTagError("Tag [selectScondary] is missing required attribute [filterbind]")
			}
			if (attrs.filter.equals('_ON')) {
				def userTemplate=grailsApplication?.config?.ajaxdependancyselection.filterField
				if (userTemplate) {
					out << g.render(template:userTemplate, model: [attrs:attrs])
				}else{
					out << g.render(contextPath: pluginContextPath, template: '/autoComplete/filterField', model: [attrs:attrs])
				}
			}
		}
		
		
		def selectSecondaryJs=grailsApplication?.config?.ajaxdependancyselection.selectSecondaryJsFilter
		if (selectSecondaryJs) {
			out << g.render(template:selectSecondaryJs, model: [attrs:attrs])
		}else{
			basicjs='/autoComplete/selectJs1'
			out << g.render(contextPath: pluginContextPath, template: basicjs, model: [attrs:attrs])
		}
		
		def gsattrs=['optionKey' : "${attrs.collectField}" , 'optionValue': "${attrs.searchField}", 'id': "${attrs.id}", 'value': "${attrs.value}", 'name': "${name}"]
		gsattrs['from'] = secondarylist
		if (requireField) {
			gsattrs['required'] = 'required'
		}
		

		gsattrs['noSelection'] =attrs.noSelection
		def changeAddon=returnAddon(attrs)
		gsattrs['onchange'] = "${remoteFunction(controller:''+attrs.controller+'', action:''+attrs.action+'', params:'\'id=\' + escape(this.value) +\'&setId='+attrs.setId+changeAddon+'&filterController='+attrs.filterController+'&filterDisplay='+attrs.filterDisplay+'&bindid='+ attrs.bindid+'&collectField='+attrs.collectField2+'&searchField='+attrs.searchField2+'&filterType='+attrs.filterType+'&filterType2='+attrs.filterType2+'&filter='+attrs.filter+'&filter2='+attrs.filter2+'&domain2='+attrs.domain2+'&prevId='+attrs.prevId+'&controller='+attrs.controller+'\'',onSuccess:''+attrs.id+'Update(data)')}"
		
		if (!attrs.secondaryValue) {
			attrs.secondaryValue=""
		}
		
		if (attrs.value) {
			out << """
				<script type='text/javascript'>
					${remoteFunction(controller:''+attrs.controller+'', action:''+attrs.action+'', params:'\'id='+attrs.value+'&value='+attrs.secondaryValue+'&setId='+attrs.setId+changeAddon+'&filterController='+attrs.filterController+'&filterDisplay='+attrs.filterDisplay+'&bindid='+ attrs.bindid+'&collectField='+attrs.collectField2+'&searchField='+attrs.searchField2+'&filterType='+attrs.filterType+'&filterType2='+attrs.filterType2+'&filter='+attrs.filter+'&filter2='+attrs.filter2+'&domain2='+attrs.domain2+'&prevId='+attrs.prevId+'&controller='+attrs.controller+'\'',onSuccess:''+attrs.id+'Update(data)')}

				</script>
			"""
		}
		
		out <<  g.select(gsattrs)
		
	}
	*/
	
	private String getFrontend() {
		def cuser=config.frontenduser ?: '_frontend'
		return cuser
	}

	private getConfig() {
		grailsApplication?.config?.boselecta
	}

}
